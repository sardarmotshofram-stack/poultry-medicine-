import { useState } from 'react';
import { Product, Sale, Purchase, TabType } from './types';
import { useLocalStorage } from './hooks/useLocalStorage';
import Layout from './components/Layout';
import Dashboard from './components/Dashboard';
import Products from './components/Products';
import Sales from './components/Sales';
import Purchases from './components/Purchases';
import ProfitLoss from './components/ProfitLoss';

function App() {
  const [activeTab, setActiveTab] = useState<TabType>('dashboard');
  const [products, setProducts] = useLocalStorage<Product[]>('poultry_products', []);
  const [sales, setSales] = useLocalStorage<Sale[]>('poultry_sales', []);
  const [purchases, setPurchases] = useLocalStorage<Purchase[]>('poultry_purchases', []);

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return <Dashboard products={products} sales={sales} purchases={purchases} />;
      case 'products':
        return <Products products={products} setProducts={setProducts} />;
      case 'sales':
        return <Sales products={products} sales={sales} setSales={setSales} setProducts={setProducts} />;
      case 'purchases':
        return <Purchases products={products} purchases={purchases} setPurchases={setPurchases} setProducts={setProducts} />;
      case 'profit':
        return <ProfitLoss sales={sales} purchases={purchases} />;
      default:
        return <Dashboard products={products} sales={sales} purchases={purchases} />;
    }
  };

  return (
    <Layout activeTab={activeTab} setActiveTab={setActiveTab}>
      {renderContent()}
    </Layout>
  );
}

export default App;
