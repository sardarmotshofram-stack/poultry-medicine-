export interface Product {
  id: string;
  name: string;
  purchasePrice: number;
  salePrice: number;
  quantity: number;
  unit: string;
  createdAt: string;
}

export interface Sale {
  id: string;
  productId: string;
  productName: string;
  quantity: number;
  unit: string;
  salePrice: number;
  purchasePrice: number;
  totalAmount: number;
  profit: number;
  date: string;
}

export interface Purchase {
  id: string;
  productId: string;
  productName: string;
  quantity: number;
  unit: string;
  purchasePrice: number;
  totalAmount: number;
  date: string;
}

export type TabType = 'dashboard' | 'products' | 'sales' | 'purchases' | 'profit';
