import { TrendingUp, TrendingDown, Calendar, FileText } from 'lucide-react';
import { Sale, Purchase } from '../types';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from 'recharts';

interface ProfitLossProps {
  sales: Sale[];
  purchases: Purchase[];
}

export default function ProfitLoss({ sales }: ProfitLossProps) {
  const totalSales = sales.reduce((sum, s) => sum + s.totalAmount, 0);
  const totalProfit = sales.reduce((sum, s) => sum + s.profit, 0);
  const totalCost = sales.reduce((sum, s) => sum + (s.purchasePrice * s.quantity), 0);

  // Monthly data
  const monthlyData = sales.reduce((acc, sale) => {
    const month = new Date(sale.date).toLocaleDateString('bn-BD', { month: 'short', year: 'numeric' });
    if (!acc[month]) {
      acc[month] = { month, sales: 0, profit: 0, cost: 0 };
    }
    acc[month].sales += sale.totalAmount;
    acc[month].profit += sale.profit;
    acc[month].cost += sale.purchasePrice * sale.quantity;
    return acc;
  }, {} as Record<string, { month: string; sales: number; profit: number; cost: number }>);

  const chartData = Object.values(monthlyData).sort((a, b) => {
    const months = ['জানু', 'ফেব্রু', 'মার্চ', 'এপ্রিল', 'মে', 'জুন', 'জুলাই', 'আগ', 'সেপ্টে', 'অক্টো', 'নভে', 'ডিসে'];
    const getMonthIndex = (m: string) => months.findIndex(x => m.includes(x));
    return getMonthIndex(a.month) - getMonthIndex(b.month);
  });

  // Product wise profit
  const productProfit = sales.reduce((acc, sale) => {
    if (!acc[sale.productName]) {
      acc[sale.productName] = { name: sale.productName, profit: 0, sales: 0 };
    }
    acc[sale.productName].profit += sale.profit;
    acc[sale.productName].sales += sale.totalAmount;
    return acc;
  }, {} as Record<string, { name: string; profit: number; sales: number }>);

  const productProfitData = Object.values(productProfit).sort((a, b) => b.profit - a.profit);

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-gray-800">লাভ-ক্ষতি বিবরণী</h2>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-5">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500">মোট বিক্রি</p>
              <p className="text-2xl font-bold text-gray-800">৳{totalSales.toFixed(2)}</p>
            </div>
            <div className="w-12 h-12 bg-blue-50 rounded-lg flex items-center justify-center">
              <FileText className="w-6 h-6 text-blue-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-5">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500">মোট ক্রয় মূল্য</p>
              <p className="text-2xl font-bold text-gray-800">৳{totalCost.toFixed(2)}</p>
            </div>
            <div className="w-12 h-12 bg-amber-50 rounded-lg flex items-center justify-center">
              <Calendar className="w-6 h-6 text-amber-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-5">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500">মোট লাভ</p>
              <p className={`text-2xl font-bold ${totalProfit >= 0 ? 'text-emerald-600' : 'text-red-600'}`}>
                ৳{totalProfit.toFixed(2)}
              </p>
            </div>
            <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${totalProfit >= 0 ? 'bg-emerald-50' : 'bg-red-50'}`}>
              {totalProfit >= 0 ? (
                <TrendingUp className="w-6 h-6 text-emerald-600" />
              ) : (
                <TrendingDown className="w-6 h-6 text-red-600" />
              )}
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-5">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500">লাভের হার</p>
              <p className={`text-2xl font-bold ${totalProfit >= 0 ? 'text-emerald-600' : 'text-red-600'}`}>
                {totalCost > 0 ? ((totalProfit / totalCost) * 100).toFixed(2) : '0.00'}%
              </p>
            </div>
            <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${totalProfit >= 0 ? 'bg-emerald-50' : 'bg-red-50'}`}>
              {totalProfit >= 0 ? (
                <TrendingUp className="w-6 h-6 text-emerald-600" />
              ) : (
                <TrendingDown className="w-6 h-6 text-red-600" />
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-5">
          <h3 className="text-lg font-semibold text-gray-800 mb-4">মাসিক বিক্রি ও লাভ</h3>
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="month" tick={{ fontSize: 12 }} />
              <YAxis tick={{ fontSize: 12 }} />
              <Tooltip formatter={(value) => `৳${Number(value).toFixed(2)}`} />
              <Bar dataKey="sales" fill="#3b82f6" name="বিক্রি" radius={[4, 4, 0, 0]} />
              <Bar dataKey="profit" fill="#10b981" name="লাভ" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-5">
          <h3 className="text-lg font-semibold text-gray-800 mb-4">লাভের প্রবণতা</h3>
          <ResponsiveContainer width="100%" height={280}>
            <LineChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="month" tick={{ fontSize: 12 }} />
              <YAxis tick={{ fontSize: 12 }} />
              <Tooltip formatter={(value) => `৳${Number(value).toFixed(2)}`} />
              <Line type="monotone" dataKey="profit" stroke="#10b981" strokeWidth={2} name="লাভ" />
              <Line type="monotone" dataKey="cost" stroke="#ef4444" strokeWidth={2} name="খরচ" />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Product Wise Profit */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-5">
        <h3 className="text-lg font-semibold text-gray-800 mb-4">পণ্য অনুযায়ী লাভ</h3>
        {productProfitData.length === 0 ? (
          <p className="text-gray-500 text-center py-8">কোনো ডেটা পাওয়া যায়নি</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-gray-100">
                  <th className="text-left py-3 px-4 text-gray-500 font-medium">#</th>
                  <th className="text-left py-3 px-4 text-gray-500 font-medium">পণ্য</th>
                  <th className="text-left py-3 px-4 text-gray-500 font-medium">মোট বিক্রি</th>
                  <th className="text-left py-3 px-4 text-gray-500 font-medium">মোট লাভ</th>
                  <th className="text-left py-3 px-4 text-gray-500 font-medium">লাভের হার</th>
                </tr>
              </thead>
              <tbody>
                {productProfitData.map((item, index) => (
                  <tr key={item.name} className="border-b border-gray-50 hover:bg-gray-50">
                    <td className="py-3 px-4 text-gray-500">{index + 1}</td>
                    <td className="py-3 px-4 font-medium text-gray-800">{item.name}</td>
                    <td className="py-3 px-4">৳{item.sales.toFixed(2)}</td>
                    <td className={`py-3 px-4 ${item.profit >= 0 ? 'text-emerald-600' : 'text-red-600'}`}>
                      ৳{item.profit.toFixed(2)}
                    </td>
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-2">
                        <div className="w-24 h-2 bg-gray-100 rounded-full overflow-hidden">
                          <div
                            className={`h-full rounded-full ${item.profit >= 0 ? 'bg-emerald-500' : 'bg-red-500'}`}
                            style={{ width: `${Math.min(Math.abs((item.profit / item.sales) * 100), 100)}%` }}
                          />
                        </div>
                        <span className="text-xs">{item.sales > 0 ? ((item.profit / item.sales) * 100).toFixed(1) : '0.0'}%</span>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
