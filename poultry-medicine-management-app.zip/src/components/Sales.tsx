import { useState } from 'react';
import { ShoppingCart, Plus, Trash2, Search } from 'lucide-react';
import { Product, Sale } from '../types';

interface SalesProps {
  products: Product[];
  sales: Sale[];
  setSales: React.Dispatch<React.SetStateAction<Sale[]>>;
  setProducts: React.Dispatch<React.SetStateAction<Product[]>>;
}

export default function Sales({ products, sales, setSales, setProducts }: SalesProps) {
  const [showForm, setShowForm] = useState(false);
  const [search, setSearch] = useState('');
  const [selectedProduct, setSelectedProduct] = useState('');
  const [quantity, setQuantity] = useState('');
  const [salePrice, setSalePrice] = useState('');

  const filteredSales = sales.filter(s =>
    s.productName.toLowerCase().includes(search.toLowerCase())
  );

  const handleProductChange = (productId: string) => {
    setSelectedProduct(productId);
    const product = products.find(p => p.id === productId);
    if (product) {
      setSalePrice(product.salePrice.toString());
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedProduct || !quantity || !salePrice) return;

    const product = products.find(p => p.id === selectedProduct);
    if (!product) return;

    const qty = parseFloat(quantity);
    if (qty > product.quantity) {
      alert('পর্যাপ্ত স্টক নেই!');
      return;
    }

    const totalAmount = qty * parseFloat(salePrice);
    const profit = qty * (parseFloat(salePrice) - product.purchasePrice);

    const newSale: Sale = {
      id: Date.now().toString(),
      productId: product.id,
      productName: product.name,
      quantity: qty,
      unit: product.unit,
      salePrice: parseFloat(salePrice),
      purchasePrice: product.purchasePrice,
      totalAmount,
      profit,
      date: new Date().toISOString(),
    };

    setSales(prev => [newSale, ...prev]);
    setProducts(prev => prev.map(p =>
      p.id === product.id ? { ...p, quantity: p.quantity - qty } : p
    ));

    setSelectedProduct('');
    setQuantity('');
    setSalePrice('');
    setShowForm(false);
  };

  const handleDelete = (sale: Sale) => {
    if (confirm('আপনি কি নিশ্চিত যে এই বিক্রি রেকর্ডটি মুছে ফেলতে চান?')) {
      setSales(prev => prev.filter(s => s.id !== sale.id));
      setProducts(prev => prev.map(p =>
        p.id === sale.productId ? { ...p, quantity: p.quantity + sale.quantity } : p
      ));
    }
  };

  const totalSalesAmount = sales.reduce((sum, s) => sum + s.totalAmount, 0);
  const totalProfit = sales.reduce((sum, s) => sum + s.profit, 0);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <h2 className="text-2xl font-bold text-gray-800">বিক্রি রেকর্ড</h2>
        <button
          onClick={() => setShowForm(!showForm)}
          className="inline-flex items-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-2 rounded-lg transition-colors"
        >
          <Plus className="w-4 h-4" />
          নতুন বিক্রি
        </button>
      </div>

      {/* Summary */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div className="bg-gradient-to-r from-emerald-50 to-teal-50 rounded-xl p-5 border border-emerald-100">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-emerald-100 rounded-lg flex items-center justify-center">
              <ShoppingCart className="w-5 h-5 text-emerald-600" />
            </div>
            <div>
              <p className="text-sm text-gray-600">মোট বিক্রি</p>
              <p className="text-xl font-bold text-gray-800">৳{totalSalesAmount.toFixed(2)}</p>
            </div>
          </div>
        </div>
        <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl p-5 border border-blue-100">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
              <ShoppingCart className="w-5 h-5 text-blue-600" />
            </div>
            <div>
              <p className="text-sm text-gray-600">মোট লাভ</p>
              <p className={`text-xl font-bold ${totalProfit >= 0 ? 'text-emerald-600' : 'text-red-600'}`}>
                ৳{totalProfit.toFixed(2)}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Form */}
      {showForm && (
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-5">
          <h3 className="text-lg font-semibold text-gray-800 mb-4">নতুন বিক্রি যোগ করুন</h3>
          <form onSubmit={handleSubmit} className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">পণ্য নির্বাচন</label>
              <select
                value={selectedProduct}
                onChange={e => handleProductChange(e.target.value)}
                className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500"
                required
              >
                <option value="">পণ্য নির্বাচন করুন</option>
                {products.map(p => (
                  <option key={p.id} value={p.id}>
                    {p.name} (স্টক: {p.quantity} {p.unit})
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">পরিমাণ</label>
              <input
                type="number"
                step="0.01"
                value={quantity}
                onChange={e => setQuantity(e.target.value)}
                className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500"
                placeholder="পরিমাণ"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">বিক্রয় মূল্য (প্রতি একক)</label>
              <input
                type="number"
                step="0.01"
                value={salePrice}
                onChange={e => setSalePrice(e.target.value)}
                className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500"
                placeholder="বিক্রয় মূল্য"
                required
              />
            </div>
            <div className="flex items-end">
              <button
                type="submit"
                className="bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-2 rounded-lg transition-colors"
              >
                বিক্রি করুন
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
        <input
          type="text"
          value={search}
          onChange={e => setSearch(e.target.value)}
          className="w-full sm:w-80 pl-10 pr-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500"
          placeholder="বিক্রি খুঁজুন..."
        />
      </div>

      {/* Sales Table */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-gray-50 border-b border-gray-100">
                <th className="text-left py-3 px-4 text-gray-500 font-medium">তারিখ</th>
                <th className="text-left py-3 px-4 text-gray-500 font-medium">পণ্য</th>
                <th className="text-left py-3 px-4 text-gray-500 font-medium">পরিমাণ</th>
                <th className="text-left py-3 px-4 text-gray-500 font-medium">একক মূল্য</th>
                <th className="text-left py-3 px-4 text-gray-500 font-medium">মোট মূল্য</th>
                <th className="text-left py-3 px-4 text-gray-500 font-medium">লাভ</th>
                <th className="text-left py-3 px-4 text-gray-500 font-medium">কার্যক্রম</th>
              </tr>
            </thead>
            <tbody>
              {filteredSales.length === 0 ? (
                <tr>
                  <td colSpan={7} className="text-center py-8 text-gray-500">
                    কোনো বিক্রি রেকর্ড পাওয়া যায়নি
                  </td>
                </tr>
              ) : (
                filteredSales.map((sale) => (
                  <tr key={sale.id} className="border-b border-gray-50 hover:bg-gray-50">
                    <td className="py-3 px-4">{new Date(sale.date).toLocaleDateString('bn-BD')}</td>
                    <td className="py-3 px-4 font-medium text-gray-800">{sale.productName}</td>
                    <td className="py-3 px-4">{sale.quantity} {sale.unit}</td>
                    <td className="py-3 px-4">৳{sale.salePrice.toFixed(2)}</td>
                    <td className="py-3 px-4 font-medium">৳{sale.totalAmount.toFixed(2)}</td>
                    <td className={`py-3 px-4 ${sale.profit >= 0 ? 'text-emerald-600' : 'text-red-600'}`}>
                      ৳{sale.profit.toFixed(2)}
                    </td>
                    <td className="py-3 px-4">
                      <button
                        onClick={() => handleDelete(sale)}
                        className="p-1.5 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                        title="মুছুন"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
