import { useState } from 'react';
import { Plus, Search, Trash2, Edit3, Package } from 'lucide-react';
import { Product } from '../types';

interface ProductsProps {
  products: Product[];
  setProducts: React.Dispatch<React.SetStateAction<Product[]>>;
}

export default function Products({ products, setProducts }: ProductsProps) {
  const [showForm, setShowForm] = useState(false);
  const [search, setSearch] = useState('');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    purchasePrice: '',
    salePrice: '',
    quantity: '',
    unit: 'পিস',
  });

  const units = ['পিস', 'বক্স', 'বোতল', 'প্যাকেট', 'কেজি', 'গ্রাম', 'লিটার', 'মিলি'];

  const filteredProducts = products.filter(p =>
    p.name.toLowerCase().includes(search.toLowerCase())
  );

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.purchasePrice || !formData.salePrice || !formData.quantity) return;

    if (editingId) {
      setProducts(prev => prev.map(p =>
        p.id === editingId
          ? {
              ...p,
              name: formData.name,
              purchasePrice: parseFloat(formData.purchasePrice),
              salePrice: parseFloat(formData.salePrice),
              quantity: parseFloat(formData.quantity),
              unit: formData.unit,
            }
          : p
      ));
      setEditingId(null);
    } else {
      const newProduct: Product = {
        id: Date.now().toString(),
        name: formData.name,
        purchasePrice: parseFloat(formData.purchasePrice),
        salePrice: parseFloat(formData.salePrice),
        quantity: parseFloat(formData.quantity),
        unit: formData.unit,
        createdAt: new Date().toISOString(),
      };
      setProducts(prev => [...prev, newProduct]);
    }

    setFormData({ name: '', purchasePrice: '', salePrice: '', quantity: '', unit: 'পিস' });
    setShowForm(false);
  };

  const handleEdit = (product: Product) => {
    setFormData({
      name: product.name,
      purchasePrice: product.purchasePrice.toString(),
      salePrice: product.salePrice.toString(),
      quantity: product.quantity.toString(),
      unit: product.unit,
    });
    setEditingId(product.id);
    setShowForm(true);
  };

  const handleDelete = (id: string) => {
    if (confirm('আপনি কি নিশ্চিত যে এই পণ্যটি মুছে ফেলতে চান?')) {
      setProducts(prev => prev.filter(p => p.id !== id));
    }
  };

  const totalStockValue = products.reduce((sum, p) => sum + (p.purchasePrice * p.quantity), 0);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <h2 className="text-2xl font-bold text-gray-800">পণ্য তালিকা</h2>
        <button
          onClick={() => {
            setShowForm(!showForm);
            setEditingId(null);
            setFormData({ name: '', purchasePrice: '', salePrice: '', quantity: '', unit: 'পিস' });
          }}
          className="inline-flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition-colors"
        >
          <Plus className="w-4 h-4" />
          নতুন পণ্য
        </button>
      </div>

      {/* Summary */}
      <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl p-5 border border-blue-100">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
            <Package className="w-5 h-5 text-blue-600" />
          </div>
          <div>
            <p className="text-sm text-gray-600">মোট স্টক মূল্য</p>
            <p className="text-xl font-bold text-gray-800">৳{totalStockValue.toFixed(2)}</p>
          </div>
        </div>
      </div>

      {/* Form */}
      {showForm && (
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-5">
          <h3 className="text-lg font-semibold text-gray-800 mb-4">
            {editingId ? 'পণ্য সম্পাদনা' : 'নতুন পণ্য যোগ করুন'}
          </h3>
          <form onSubmit={handleSubmit} className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">পণ্যের নাম</label>
              <input
                type="text"
                value={formData.name}
                onChange={e => setFormData({ ...formData, name: e.target.value })}
                className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="পণ্যের নাম"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">ক্রয় মূল্য</label>
              <input
                type="number"
                step="0.01"
                value={formData.purchasePrice}
                onChange={e => setFormData({ ...formData, purchasePrice: e.target.value })}
                className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="ক্রয় মূল্য"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">বিক্রয় মূল্য</label>
              <input
                type="number"
                step="0.01"
                value={formData.salePrice}
                onChange={e => setFormData({ ...formData, salePrice: e.target.value })}
                className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="বিক্রয় মূল্য"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">পরিমাণ</label>
              <input
                type="number"
                step="0.01"
                value={formData.quantity}
                onChange={e => setFormData({ ...formData, quantity: e.target.value })}
                className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="পরিমাণ"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">একক</label>
              <select
                value={formData.unit}
                onChange={e => setFormData({ ...formData, unit: e.target.value })}
                className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                {units.map(u => <option key={u} value={u}>{u}</option>)}
              </select>
            </div>
            <div className="sm:col-span-2 lg:col-span-5 flex gap-2">
              <button
                type="submit"
                className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition-colors"
              >
                {editingId ? 'আপডেট' : 'যোগ করুন'}
              </button>
              <button
                type="button"
                onClick={() => {
                  setShowForm(false);
                  setEditingId(null);
                }}
                className="bg-gray-100 hover:bg-gray-200 text-gray-700 px-4 py-2 rounded-lg transition-colors"
              >
                বাতিল
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
        <input
          type="text"
          value={search}
          onChange={e => setSearch(e.target.value)}
          className="w-full sm:w-80 pl-10 pr-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          placeholder="পণ্য খুঁজুন..."
        />
      </div>

      {/* Products Table */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-gray-50 border-b border-gray-100">
                <th className="text-left py-3 px-4 text-gray-500 font-medium">#</th>
                <th className="text-left py-3 px-4 text-gray-500 font-medium">পণ্যের নাম</th>
                <th className="text-left py-3 px-4 text-gray-500 font-medium">ক্রয় মূল্য</th>
                <th className="text-left py-3 px-4 text-gray-500 font-medium">বিক্রয় মূল্য</th>
                <th className="text-left py-3 px-4 text-gray-500 font-medium">স্টক</th>
                <th className="text-left py-3 px-4 text-gray-500 font-medium">মোট মূল্য</th>
                <th className="text-left py-3 px-4 text-gray-500 font-medium">কার্যক্রম</th>
              </tr>
            </thead>
            <tbody>
              {filteredProducts.length === 0 ? (
                <tr>
                  <td colSpan={7} className="text-center py-8 text-gray-500">
                    কোনো পণ্য পাওয়া যায়নি
                  </td>
                </tr>
              ) : (
                filteredProducts.map((product, index) => (
                  <tr key={product.id} className="border-b border-gray-50 hover:bg-gray-50">
                    <td className="py-3 px-4 text-gray-500">{index + 1}</td>
                    <td className="py-3 px-4 font-medium text-gray-800">{product.name}</td>
                    <td className="py-3 px-4">৳{product.purchasePrice.toFixed(2)}</td>
                    <td className="py-3 px-4">৳{product.salePrice.toFixed(2)}</td>
                    <td className="py-3 px-4">
                      <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                        product.quantity <= 5 ? 'bg-red-50 text-red-700' : 'bg-emerald-50 text-emerald-700'
                      }`}>
                        {product.quantity} {product.unit}
                      </span>
                    </td>
                    <td className="py-3 px-4">৳{(product.purchasePrice * product.quantity).toFixed(2)}</td>
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => handleEdit(product)}
                          className="p-1.5 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                          title="সম্পাদনা"
                        >
                          <Edit3 className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleDelete(product.id)}
                          className="p-1.5 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                          title="মুছুন"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
