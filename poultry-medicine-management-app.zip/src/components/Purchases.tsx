import { useState } from 'react';
import { ShoppingBag, Plus, Trash2, Search } from 'lucide-react';
import { Product, Purchase } from '../types';

interface PurchasesProps {
  products: Product[];
  purchases: Purchase[];
  setPurchases: React.Dispatch<React.SetStateAction<Purchase[]>>;
  setProducts: React.Dispatch<React.SetStateAction<Product[]>>;
}

export default function Purchases({ products, purchases, setPurchases, setProducts }: PurchasesProps) {
  const [showForm, setShowForm] = useState(false);
  const [search, setSearch] = useState('');
  const [selectedProduct, setSelectedProduct] = useState('');
  const [quantity, setQuantity] = useState('');
  const [purchasePrice, setPurchasePrice] = useState('');

  const filteredPurchases = purchases.filter(p =>
    p.productName.toLowerCase().includes(search.toLowerCase())
  );

  const handleProductChange = (productId: string) => {
    setSelectedProduct(productId);
    const product = products.find(p => p.id === productId);
    if (product) {
      setPurchasePrice(product.purchasePrice.toString());
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedProduct || !quantity || !purchasePrice) return;

    const product = products.find(p => p.id === selectedProduct);
    if (!product) return;

    const qty = parseFloat(quantity);
    const totalAmount = qty * parseFloat(purchasePrice);

    const newPurchase: Purchase = {
      id: Date.now().toString(),
      productId: product.id,
      productName: product.name,
      quantity: qty,
      unit: product.unit,
      purchasePrice: parseFloat(purchasePrice),
      totalAmount,
      date: new Date().toISOString(),
    };

    setPurchases(prev => [newPurchase, ...prev]);
    setProducts(prev => prev.map(p =>
      p.id === product.id ? { ...p, quantity: p.quantity + qty } : p
    ));

    setSelectedProduct('');
    setQuantity('');
    setPurchasePrice('');
    setShowForm(false);
  };

  const handleDelete = (purchase: Purchase) => {
    if (confirm('আপনি কি নিশ্চিত যে এই ক্রয় রেকর্ডটি মুছে ফেলতে চান?')) {
      setPurchases(prev => prev.filter(p => p.id !== purchase.id));
      setProducts(prev => prev.map(p =>
        p.id === purchase.productId ? { ...p, quantity: p.quantity - purchase.quantity } : p
      ));
    }
  };

  const totalPurchaseAmount = purchases.reduce((sum, p) => sum + p.totalAmount, 0);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <h2 className="text-2xl font-bold text-gray-800">ক্রয় রেকর্ড</h2>
        <button
          onClick={() => setShowForm(!showForm)}
          className="inline-flex items-center gap-2 bg-amber-600 hover:bg-amber-700 text-white px-4 py-2 rounded-lg transition-colors"
        >
          <Plus className="w-4 h-4" />
          নতুন ক্রয়
        </button>
      </div>

      {/* Summary */}
      <div className="bg-gradient-to-r from-amber-50 to-orange-50 rounded-xl p-5 border border-amber-100">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-amber-100 rounded-lg flex items-center justify-center">
            <ShoppingBag className="w-5 h-5 text-amber-600" />
          </div>
          <div>
            <p className="text-sm text-gray-600">মোট ক্রয়</p>
            <p className="text-xl font-bold text-gray-800">৳{totalPurchaseAmount.toFixed(2)}</p>
          </div>
        </div>
      </div>

      {/* Form */}
      {showForm && (
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-5">
          <h3 className="text-lg font-semibold text-gray-800 mb-4">নতুন ক্রয় যোগ করুন</h3>
          <form onSubmit={handleSubmit} className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">পণ্য নির্বাচন</label>
              <select
                value={selectedProduct}
                onChange={e => handleProductChange(e.target.value)}
                className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500"
                required
              >
                <option value="">পণ্য নির্বাচন করুন</option>
                {products.map(p => (
                  <option key={p.id} value={p.id}>
                    {p.name} (বর্তমান স্টক: {p.quantity} {p.unit})
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">পরিমাণ</label>
              <input
                type="number"
                step="0.01"
                value={quantity}
                onChange={e => setQuantity(e.target.value)}
                className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500"
                placeholder="পরিমাণ"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">ক্রয় মূল্য (প্রতি একক)</label>
              <input
                type="number"
                step="0.01"
                value={purchasePrice}
                onChange={e => setPurchasePrice(e.target.value)}
                className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500"
                placeholder="ক্রয় মূল্য"
                required
              />
            </div>
            <div className="flex items-end">
              <button
                type="submit"
                className="bg-amber-600 hover:bg-amber-700 text-white px-4 py-2 rounded-lg transition-colors"
              >
                ক্রয় করুন
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
        <input
          type="text"
          value={search}
          onChange={e => setSearch(e.target.value)}
          className="w-full sm:w-80 pl-10 pr-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500"
          placeholder="ক্রয় খুঁজুন..."
        />
      </div>

      {/* Purchases Table */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-gray-50 border-b border-gray-100">
                <th className="text-left py-3 px-4 text-gray-500 font-medium">তারিখ</th>
                <th className="text-left py-3 px-4 text-gray-500 font-medium">পণ্য</th>
                <th className="text-left py-3 px-4 text-gray-500 font-medium">পরিমাণ</th>
                <th className="text-left py-3 px-4 text-gray-500 font-medium">একক মূল্য</th>
                <th className="text-left py-3 px-4 text-gray-500 font-medium">মোট মূল্য</th>
                <th className="text-left py-3 px-4 text-gray-500 font-medium">কার্যক্রম</th>
              </tr>
            </thead>
            <tbody>
              {filteredPurchases.length === 0 ? (
                <tr>
                  <td colSpan={6} className="text-center py-8 text-gray-500">
                    কোনো ক্রয় রেকর্ড পাওয়া যায়নি
                  </td>
                </tr>
              ) : (
                filteredPurchases.map((purchase) => (
                  <tr key={purchase.id} className="border-b border-gray-50 hover:bg-gray-50">
                    <td className="py-3 px-4">{new Date(purchase.date).toLocaleDateString('bn-BD')}</td>
                    <td className="py-3 px-4 font-medium text-gray-800">{purchase.productName}</td>
                    <td className="py-3 px-4">{purchase.quantity} {purchase.unit}</td>
                    <td className="py-3 px-4">৳{purchase.purchasePrice.toFixed(2)}</td>
                    <td className="py-3 px-4 font-medium">৳{purchase.totalAmount.toFixed(2)}</td>
                    <td className="py-3 px-4">
                      <button
                        onClick={() => handleDelete(purchase)}
                        className="p-1.5 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                        title="মুছুন"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
